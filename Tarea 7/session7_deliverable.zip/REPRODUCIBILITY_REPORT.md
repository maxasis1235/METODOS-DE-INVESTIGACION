# Reproducibility Report - Session 7 (Ancash Quechua multi-agent tutor)
_Generated 2026-10-22 22:07 UTC_

## Environment
- Python: 3.13.16 | OS: Linux-6.6.122+-x86_64-with-glibc2.39
- numpy 2.1.3 | pandas 2.2.3 | scikit-learn 1.6.1 | scipy 1.16.3
- Global RANDOM_STATE: 42; data generator seed: 2026
- Dataset: SYNTHETIC learner interactions (9,600 rows, 240 learners, 40 features)

## Headline results (measured in this run; SYNTHETIC data)
- Fancy model (GBM) test accuracy: 0.6958  | tuned logistic baseline: 0.7167  | untuned: 0.6142
- 10-seed accuracy: 0.7057 ± 0.0109
- Paired t-test (10 seeds, fancy vs tuned baseline): p = 0.008052
- McNemar exact p (single test set): 0.0003789
- Learner-level cluster-bootstrap 95% CI of the difference: [-0.0467, -0.0029]

## Artifacts in this bundle
- model_card.md (9 sections) | datasheet.md (7 sections) | annex_iv_crosswalk.md | FINDINGS.md
- synthetic_interactions.csv | skills_catalog_ILLUSTRATIVE.csv | run_config.json | requirements_snapshot.txt
- fig_seed_variance.png, fig_compute_matched.png, fig_ablation_errorbars.png

## Documentation scorecard
- Score: 8/8 (course checks) | project-specific bonus: 4/4

## How to re-run
Open the notebook in Colab (CPU), Runtime > Run all. All randomness is seeded; expect the same numbers with the same library versions.
To use real data: replace `simulate_interactions()` with your loader keeping the columns of `df`, and rewrite the Datasheet.