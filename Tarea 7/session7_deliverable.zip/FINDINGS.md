# Automatic findings (SYNTHETIC data — not results about real learners)

1. **Fair baseline (Ex. 1).** Apparent improvement over the weak baseline: +0.0817; improvement against the tuned baseline: -0.0208 (heuristic: 0.6146; majority: 0.6142).
2. **Variance (Ex. 2).** Accuracy 0.7057 ± 0.0109 over 10 seeds; range 0.6942–0.7329.
3. **Ablation (Ex. 3/10).** Components whose Δ survives Holm (α=0.05): – remove learner history (learner-model agent), – remove item / skill.
4. **Significance (Ex. 7).** Paired t-test p=0.008052; McNemar p=0.0003789; Δ vs baseline learner-level 95% CI [-0.0467, -0.0029] -> detectable difference.
5. **Compute (Ex. 8).** Budgets at which boosting beats the tuned baseline: none.
6. **Leakage (Ex. 9).** Pure noise: leaky CV 0.892 vs honest 0.600 (chance 0.625). Learner future-information feature: ΔAUC +0.050; row-level split: ΔAUC +0.009.
7. **Compliance (Ex. 11).** Gaps in the Annex IV crosswalk: 5 of 9 elements.

**Central limitation:** everything above describes a simulator with a logistic response model; it does not transfer without validation with real students and speakers.