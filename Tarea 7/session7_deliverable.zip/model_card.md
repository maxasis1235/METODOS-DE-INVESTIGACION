# Model Card — QuechuaTutor Learner-Model Agent (Ancash Quechua tutor)

## Model details
- **Name / version:** QuechuaTutor-LearnerModel (gradient boosting) v0.1 - synthetic-data research prototype
- **Owner / contact:** Maximiliano Asis Lopez <maximiliano.asisl@unmsm.edu.pe> - UNMSM Doctoral Program in Deep Technologies
- **Date:** 2026-10
- **Architecture:** Gradient Boosting (200 trees, depth 3) on standardised history / item / profile / interaction features. Component of a multi-agent tutor (curriculum planner, LLM dialogue tutor, assessment, feedback, cultural-linguistic validator).
- **License:** UNKNOWN — to investigate

## Intended use
- **Primary intended uses:** Research prototype to exercise the Session-7 benchmarking and documentation protocol; predicts whether a learner answers the next exercise correctly, to feed the curriculum-planner agent.
- **Out-of-scope / misuse:** NOT for grading, certification, placement or any high-stakes decision about real learners. NOT validated on real Ancash Quechua learners. NOT a judge of Quechua correctness: it never evaluates Quechua text.
- **Intended users:** Thesis author and, later, tutor developers working with linguist / community oversight.

## Factors
- **Relevant groups / conditions:** SIMULATED attributes only: heritage vs L2 learner, age band, device, connectivity. Real factors ABSENT: dialect variant (Huaylas, Conchucos), Spanish literacy, orthography used, prior bilingualism. Which real factors matter: UNKNOWN — to investigate.
- **Evaluation factors:** Reported overall, per class, and per simulated subgroup (heritage, connectivity, device, age band).

## Metrics
- **Performance measures:** Accuracy (primary), ROC-AUC, macro-F1
- **Decision thresholds:** 0.5 default; probability calibration not assessed
- **Variation approach:** Mean ± std over 10 seeds (each seed = different learner-level split + model seed); paired t-test / Wilcoxon, exact McNemar and learner-level cluster-bootstrap CI for comparisons

## Evaluation data
- **Datasets:** 25% held-out SIMULATED learners (60 of 240), split by learner so no learner appears in both train and test
- **Preprocessing:** StandardScaler fit on the training split only; history features computed from prior attempts only

## Training data
- **Datasets:** 75% of simulated learners (180 of 240; 7,200 interactions); generator seed 2026
- **Known limitations:** 100% synthetic; IRT-style generator favours linear models; no real learner or Quechua-speaker data; 12-skill catalogue is illustrative and not validated by native speakers

## Quantitative analyses
- **Overall results:** accuracy=0.6958, macro-F1=0.6631, ROC-AUC=0.7325 on the main split; 10-seed accuracy 0.7057 ± 0.0109 (std). Tuned logistic-regression baseline on the main split: accuracy=0.7167 (majority-class: 0.6142). SIMULATED data.
- **Disaggregated results:** per-class recall: {'wrong': 0.4978, 'correct': 0.8202}; per-group accuracy (simulated attributes, small groups are noisy): {'heritage_speaker=0': '0.663 (n=1440)', 'heritage_speaker=1': '0.745 (n=960)', 'connectivity=high': '0.699 (n=1320)', 'connectivity=low': '0.692 (n=1080)', 'device=desktop': '0.713 (n=560)', 'device=mobile': '0.691 (n=1840)', 'age_band=13-17': '0.730 (n=560)', 'age_band=18-29': '0.689 (n=800)', 'age_band=30-49': '0.661 (n=720)', 'age_band=50+': '0.731 (n=320)'}

## Ethical considerations
- **Risks:** Adapting teaching with age / heritage / connectivity could stereotype learners or penalise low-connectivity users; modelling an Indigenous language without community governance risks extractive or inaccurate representation; simulated results could be mistaken for real evidence.
- **Mitigations:** Marked research prototype, no deployment; profile block is ablated (Ex. 3) to test whether it is needed; planned: native-speaker validation, informed consent and community consultation (CARE principles for Indigenous data governance).

## Caveats and recommendations
- **Caveats:** Every number describes a simulator, not learners. The ranking gradient boosting vs logistic regression may flip on real data.
- **Recommendations:** Before any real use: (1) validate the skill catalogue with Ancash Quechua speakers / linguists; (2) collect real interaction data with informed consent; (3) re-run the full protocol (tuned baselines, >=5 seeds, significance tests, subgroup analysis); (4) keep a human in the loop for pedagogical decisions.
