# EU AI Act - Annex IV Crosswalk (educational)

_Mapping of Model Card / Datasheet sections to Annex IV technical-documentation elements._
_Regulation (EU) 2024/1689 as amended by Regulation (EU) 2026/1744 (Digital Omnibus on AI): stand-alone Annex III high-risk obligations apply from 2 December 2027 (originally 2 August 2026). Verify against EUR-Lex._
_Educational documentation exercise; not legal advice and not a conformity assessment._

| Annex IV element | Source | Maps to section(s) | Status | Needs attention |
|---|---|---|---|---|
| IV(1) General description of the AI system (purpose, developer, version) | Model Card | Model details, Intended use | GAP | Model details: License |
| IV(2) Elements & development process (design choices, data, training) | Model Card | Training data, Evaluation data, Metrics | COVERED | - |
| IV(3) Monitoring, functioning & control (capabilities, limitations, accuracy) | Model Card | Factors, Quantitative analyses | GAP | Factors: Relevant groups / conditions |
| IV(4) Appropriateness of performance metrics | Model Card | Metrics, Quantitative analyses | COVERED | - |
| IV(5) Risk management (foreseeable risks & mitigations) | Model Card | Ethical considerations | COVERED | - |
| IV(8) Post-market monitoring / known limitations & recommendations | Model Card | Caveats and recommendations | COVERED | - |
| Data requirements & data governance (datasheet-like) | Datasheet | Composition, Collection process, Preprocessing / cleaning / labeling | GAP | Collection process: Consent / ethics |
| Human-oversight measures (design of the human-in-the-loop for teachers / learners) | - | (no counterpart) | GAP | Write a separate document; not covered by Model Card / Datasheet |
| Cybersecurity, robustness & accuracy measures of the full multi-agent / LLM system | - | (no counterpart) | GAP | Write a separate document; not covered by Model Card / Datasheet |